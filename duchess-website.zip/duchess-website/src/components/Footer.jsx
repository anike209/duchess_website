import { Link } from 'react-router-dom'
import Monogram from './Monogram'

export default function Footer() {
  return (
    <footer className="bg-ink text-cream mt-24">
      <div className="max-w-6xl mx-auto px-5 py-14 grid gap-10 md:grid-cols-3">
        <div>
          <div className="flex items-center gap-2 mb-3">
            <Monogram className="w-8 h-8" light />
            <span className="font-display text-lg">Duchess</span>
          </div>
          <p className="text-cream/60 text-sm max-w-xs leading-relaxed">
            Shawarma, pizza, cakes, pastries & custom celebration orders.
            Unofficial concept site — not yet affiliated with the business.
          </p>
        </div>

        <div>
          <p className="text-gold text-sm mb-3 font-display">Explore</p>
          <ul className="space-y-2 text-sm text-cream/70">
            <li><Link to="/menu" className="hover:text-cream">Menu</Link></li>
            <li><Link to="/custom-orders" className="hover:text-cream">Custom Orders</Link></li>
            <li><Link to="/locations" className="hover:text-cream">Locations</Link></li>
            <li><Link to="/about" className="hover:text-cream">About</Link></li>
            <li><Link to="/admin" className="hover:text-cream">Admin</Link></li>
          </ul>
        </div>

        <div>
          <p className="text-gold text-sm mb-3 font-display">Built by</p>
          <p className="text-sm text-cream/70">
            BuildWithSawdah<br />
            <a href="https://instagram.com/BuildWithSawdah" className="hover:text-cream underline underline-offset-2">
              @BuildWithSawdah
            </a>
            <br />
            tirmidhysawdah@gmail.com
          </p>
        </div>
      </div>
      <div className="hairline opacity-30" />
      <p className="text-center text-xs text-cream/40 py-5">
        © {new Date().getFullYear()} Duchess concept site — demo build, all product data subject to confirmation.
      </p>
    </footer>
  )
}
