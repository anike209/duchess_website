import PlaceholderArt from './PlaceholderArt'

export default function ProductCard({ product, selected, qty, onToggle, onQtyChange }) {
  const unavailable = product.is_available === false

  return (
    <div className={`group border border-gold/25 bg-white/40 ${unavailable ? 'opacity-50' : ''}`}>
      <div className="aspect-[4/3]">
        {product.image_url ? (
          <img src={product.image_url} alt={product.name} className="w-full h-full object-cover" />
        ) : (
          <PlaceholderArt label={product.name} className="w-full h-full" />
        )}
      </div>
      <div className="p-4">
        <div className="flex items-start justify-between gap-3">
          <h3 className="font-display text-lg leading-snug text-ink">{product.name}</h3>
          <span className="font-body text-sm text-burgundy whitespace-nowrap pt-0.5">
            {product.price ? `₦${Number(product.price).toLocaleString()}` : 'Price on request'}
          </span>
        </div>
        {product.description && (
          <p className="text-sm text-charcoal/70 mt-1.5 leading-relaxed">{product.description}</p>
        )}

        {unavailable ? (
          <p className="mt-3 text-xs uppercase tracking-wide text-charcoal/50">Currently unavailable</p>
        ) : onToggle ? (
          <div className="mt-3 flex items-center gap-3">
            <button
              onClick={() => onToggle(product)}
              className={`text-sm px-3 py-1.5 border transition ${
                selected
                  ? 'bg-burgundy text-cream border-burgundy'
                  : 'border-charcoal/30 text-charcoal hover:border-burgundy'
              }`}
            >
              {selected ? 'Added' : 'Add to order'}
            </button>
            {selected && (
              <input
                type="number"
                min="1"
                value={qty}
                onChange={(e) => onQtyChange(product, Math.max(1, Number(e.target.value)))}
                className="w-14 border border-charcoal/20 px-2 py-1 text-sm text-center"
                aria-label={`Quantity for ${product.name}`}
              />
            )}
          </div>
        ) : null}
      </div>
    </div>
  )
}
