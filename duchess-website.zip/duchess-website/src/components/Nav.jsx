import { NavLink } from 'react-router-dom'
import { useState } from 'react'
import Monogram from './Monogram'

const links = [
  { to: '/', label: 'Home' },
  { to: '/menu', label: 'Menu' },
  { to: '/custom-orders', label: 'Custom Orders' },
  { to: '/locations', label: 'Locations' },
  { to: '/about', label: 'About' },
]

export default function Nav() {
  const [open, setOpen] = useState(false)

  return (
    <header className="sticky top-0 z-40 bg-cream/95 backdrop-blur border-b border-gold/30">
      <div className="max-w-6xl mx-auto px-5 h-16 flex items-center justify-between">
        <NavLink to="/" className="flex items-center gap-2" onClick={() => setOpen(false)}>
          <Monogram className="w-8 h-8" />
          <span className="font-display text-lg tracking-tight text-ink">Duchess</span>
        </NavLink>

        <nav className="hidden md:flex items-center gap-8">
          {links.map((l) => (
            <NavLink
              key={l.to}
              to={l.to}
              className={({ isActive }) =>
                `text-sm font-body transition-colors ${
                  isActive ? 'text-burgundy' : 'text-charcoal/80 hover:text-burgundy'
                }`
              }
            >
              {l.label}
            </NavLink>
          ))}
        </nav>

        <button
          className="md:hidden p-2 -mr-2"
          aria-label={open ? 'Close menu' : 'Open menu'}
          aria-expanded={open}
          onClick={() => setOpen(!open)}
        >
          <div className="w-6 h-[1.5px] bg-ink mb-1.5" />
          <div className="w-6 h-[1.5px] bg-ink mb-1.5" />
          <div className="w-4 h-[1.5px] bg-ink" />
        </button>
      </div>

      {open && (
        <nav className="md:hidden border-t border-gold/30 bg-cream px-5 py-3 flex flex-col gap-1">
          {links.map((l) => (
            <NavLink
              key={l.to}
              to={l.to}
              onClick={() => setOpen(false)}
              className={({ isActive }) =>
                `py-2.5 text-base ${isActive ? 'text-burgundy' : 'text-charcoal/85'}`
              }
            >
              {l.label}
            </NavLink>
          ))}
        </nav>
      )}
    </header>
  )
}
