export default function Monogram({ className = 'w-9 h-9', light = false }) {
  const stroke = light ? '#FAF3E7' : '#7A1F2B'
  return (
    <svg viewBox="0 0 40 40" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
      <circle cx="20" cy="20" r="19" stroke={stroke} strokeWidth="1" />
      <text
        x="20"
        y="27"
        textAnchor="middle"
        fontFamily="Fraunces, serif"
        fontSize="19"
        fill={stroke}
      >
        D
      </text>
    </svg>
  )
}
