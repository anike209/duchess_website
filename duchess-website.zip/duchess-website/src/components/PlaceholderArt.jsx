const PALETTES = [
  ['#7A1F2B', '#3D0F16'],
  ['#241016', '#7A1F2B'],
  ['#C9A24B', '#7A1F2B'],
  ['#3D0F16', '#C9A24B'],
]

function hashToIndex(str, len) {
  let h = 0
  for (let i = 0; i < (str || '').length; i++) h = (h * 31 + str.charCodeAt(i)) >>> 0
  return h % len
}

export default function PlaceholderArt({ label = 'Duchess', className = '' }) {
  const [from, to] = PALETTES[hashToIndex(label, PALETTES.length)]
  const initial = (label || 'D').trim().charAt(0).toUpperCase()

  return (
    <div
      className={`relative flex items-center justify-center overflow-hidden ${className}`}
      style={{ background: `linear-gradient(135deg, ${from}, ${to})` }}
    >
      <span className="font-display text-cream/25 select-none" style={{ fontSize: '4rem' }}>
        {initial}
      </span>
      <span className="absolute bottom-2 right-2 text-[10px] tracking-wide text-cream/50 font-body">
        Photo coming soon
      </span>
    </div>
  )
}
