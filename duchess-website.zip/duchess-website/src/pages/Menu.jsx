import { useEffect, useMemo, useState } from 'react'
import { supabase } from '../lib/supabase'
import { useSiteSettings } from '../lib/useSiteSettings'
import { buildWhatsAppLink, buildOrderMessage } from '../lib/whatsapp'
import ProductCard from '../components/ProductCard'

export default function Menu() {
  const [categories, setCategories] = useState([])
  const [products, setProducts] = useState([])
  const [branches, setBranches] = useState([])
  const [activeCategory, setActiveCategory] = useState('all')
  const [order, setOrder] = useState({}) // { productId: qty }
  const [branchId, setBranchId] = useState('')
  const settings = useSiteSettings()

  useEffect(() => {
    supabase.from('categories').select('*').order('sort_order').then(({ data }) => setCategories(data || []))
    supabase.from('products').select('*').order('created_at').then(({ data }) => setProducts(data || []))
    supabase.from('branches').select('*').then(({ data }) => setBranches(data || []))
  }, [])

  const filtered = useMemo(() => {
    if (activeCategory === 'all') return products
    return products.filter((p) => p.category_id === activeCategory)
  }, [products, activeCategory])

  const orderItems = useMemo(() => {
    return Object.entries(order)
      .filter(([, qty]) => qty > 0)
      .map(([id, qty]) => {
        const product = products.find((p) => p.id === id)
        return product ? { name: product.name, qty } : null
      })
      .filter(Boolean)
  }, [order, products])

  function toggle(product) {
    setOrder((prev) => {
      const next = { ...prev }
      if (next[product.id]) delete next[product.id]
      else next[product.id] = 1
      return next
    })
  }

  function setQty(product, qty) {
    setOrder((prev) => ({ ...prev, [product.id]: qty }))
  }

  const branchName = branches.find((b) => b.id === branchId)?.name
  const waLink = buildWhatsAppLink(
    settings?.whatsapp_number,
    buildOrderMessage({ items: orderItems, branchName })
  )

  return (
    <div className="max-w-6xl mx-auto px-5 py-12 md:py-16">
      <h1 className="font-display text-3xl md:text-4xl text-ink mb-2">Menu</h1>
      <p className="text-charcoal/60 mb-8">Browse, select what you want, and send it straight to WhatsApp.</p>

      {/* Category filter — horizontal scroll on mobile */}
      <div className="flex gap-2 overflow-x-auto pb-3 mb-8 -mx-5 px-5 md:mx-0 md:px-0">
        <button
          onClick={() => setActiveCategory('all')}
          className={`shrink-0 px-4 py-2 text-sm border ${activeCategory === 'all' ? 'bg-ink text-cream border-ink' : 'border-charcoal/20'}`}
        >
          All
        </button>
        {categories.map((c) => (
          <button
            key={c.id}
            onClick={() => setActiveCategory(c.id)}
            className={`shrink-0 px-4 py-2 text-sm border ${activeCategory === c.id ? 'bg-ink text-cream border-ink' : 'border-charcoal/20'}`}
          >
            {c.name}
          </button>
        ))}
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5 mb-28">
        {filtered.map((p) => (
          <ProductCard
            key={p.id}
            product={p}
            selected={!!order[p.id]}
            qty={order[p.id] || 1}
            onToggle={toggle}
            onQtyChange={setQty}
          />
        ))}
        {filtered.length === 0 && (
          <p className="text-charcoal/50 col-span-full py-10 text-center">No products in this category yet.</p>
        )}
      </div>

      {/* Sticky order summary */}
      {orderItems.length > 0 && (
        <div className="fixed bottom-0 left-0 right-0 z-40 bg-ink text-cream border-t border-gold/30">
          <div className="max-w-6xl mx-auto px-5 py-4 flex flex-col sm:flex-row sm:items-center gap-3 sm:gap-6">
            <div className="text-sm flex-1 min-w-0">
              <span className="text-gold">{orderItems.length} item{orderItems.length > 1 ? 's' : ''} selected</span>
              <span className="text-cream/50"> — {orderItems.map((i) => `${i.qty}× ${i.name}`).join(', ')}</span>
            </div>
            {branches.length > 0 && (
              <select
                value={branchId}
                onChange={(e) => setBranchId(e.target.value)}
                className="bg-transparent border border-cream/30 px-3 py-2 text-sm"
              >
                <option value="" className="text-ink">Select branch</option>
                {branches.map((b) => (
                  <option key={b.id} value={b.id} className="text-ink">{b.name}</option>
                ))}
              </select>
            )}
            <a
              href={waLink}
              target="_blank"
              rel="noopener noreferrer"
              className="bg-burgundy px-6 py-2.5 text-sm font-medium text-center hover:brightness-110 transition"
            >
              Order via WhatsApp
            </a>
          </div>
        </div>
      )}
    </div>
  )
}
