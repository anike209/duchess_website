import { useEffect, useState } from 'react'
import { supabase } from '../lib/supabase'
import { useSiteSettings } from '../lib/useSiteSettings'
import { buildWhatsAppLink } from '../lib/whatsapp'

export default function Locations() {
  const [branches, setBranches] = useState([])
  const settings = useSiteSettings()

  useEffect(() => {
    supabase.from('branches').select('*').then(({ data }) => setBranches(data || []))
  }, [])

  return (
    <div className="max-w-6xl mx-auto px-5 py-12 md:py-16">
      <h1 className="font-display text-3xl md:text-4xl text-ink mb-2">Locations</h1>
      <p className="text-charcoal/60 mb-10">Find the branch nearest you.</p>

      {branches.length === 0 && (
        <p className="text-charcoal/50 py-10 text-center border border-dashed border-charcoal/20">
          No branches added yet — check back soon.
        </p>
      )}

      <div className="grid sm:grid-cols-2 gap-6">
        {branches.map((b) => (
          <div key={b.id} className="border border-gold/25 p-6">
            <h2 className="font-display text-xl text-ink mb-3">{b.name}</h2>
            <dl className="space-y-1.5 text-sm text-charcoal/70 mb-5">
              <div><dt className="inline text-charcoal/50">Address: </dt><dd className="inline">{b.address || '[Address to be confirmed]'}</dd></div>
              <div><dt className="inline text-charcoal/50">Hours: </dt><dd className="inline">{b.hours || '[Hours to be confirmed]'}</dd></div>
              {b.phone && <div><dt className="inline text-charcoal/50">Phone: </dt><dd className="inline">{b.phone}</dd></div>}
            </dl>
            <div className="flex flex-wrap gap-3">
              {b.maps_link && (
                <a href={b.maps_link} target="_blank" rel="noopener noreferrer" className="text-sm border border-charcoal/25 px-4 py-2 hover:border-burgundy">
                  Get directions
                </a>
              )}
              <a
                href={buildWhatsAppLink(settings?.whatsapp_number, `Hello Duchess, I'd like to order from your ${b.name} branch.`)}
                target="_blank"
                rel="noopener noreferrer"
                className="text-sm bg-burgundy text-cream px-4 py-2 hover:brightness-110"
              >
                Order from this location
              </a>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
