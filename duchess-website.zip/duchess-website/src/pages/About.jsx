import { useEffect, useState } from 'react'
import { supabase } from '../lib/supabase'
import { useSiteSettings } from '../lib/useSiteSettings'
import { buildWhatsAppLink } from '../lib/whatsapp'
import PlaceholderArt from '../components/PlaceholderArt'

export default function About() {
  const [promotions, setPromotions] = useState([])
  const settings = useSiteSettings()

  useEffect(() => {
    supabase.from('promotions').select('*').eq('is_active', true).then(({ data }) => setPromotions(data || []))
  }, [])

  const galleryLabels = ['Shawarma', 'Pizza', 'Cakes', 'Parfait', 'Meals', 'Pastries']

  return (
    <div>
      <section className="max-w-6xl mx-auto px-5 py-16 md:py-20 grid md:grid-cols-2 gap-12 items-center">
        <div>
          <p className="text-burgundy text-sm tracking-wide mb-4">Our story</p>
          <h1 className="font-display text-4xl md:text-5xl text-ink leading-tight mb-6">
            [Duchess's story goes here]
          </h1>
          <p className="text-charcoal/70 leading-relaxed max-w-md">
            [PLACEHOLDER — add Duchess's real story once confirmed: how it started, what makes
            the food distinct, and what the brand stands for.]
          </p>
        </div>
        <div className="aspect-square">
          <PlaceholderArt label="Our Story" className="w-full h-full" />
        </div>
      </section>

      {promotions.length > 0 && (
        <section className="bg-blush/40 py-16">
          <div className="max-w-6xl mx-auto px-5">
            <h2 className="font-display text-2xl text-ink mb-8">Right now at Duchess</h2>
            <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-5">
              {promotions.map((p) => (
                <div key={p.id} className="aspect-[4/3] relative flex items-end p-4">
                  {p.image_url ? (
                    <img src={p.image_url} alt={p.title} className="absolute inset-0 w-full h-full object-cover" />
                  ) : (
                    <PlaceholderArt label={p.title || 'Promo'} className="absolute inset-0" />
                  )}
                  <span className="relative text-cream font-display text-lg">{p.title}</span>
                </div>
              ))}
            </div>
          </div>
        </section>
      )}

      <section className="max-w-6xl mx-auto px-5 py-16">
        <h2 className="font-display text-2xl text-ink mb-8">Gallery</h2>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
          {galleryLabels.map((label) => (
            <div key={label} className="aspect-square">
              <PlaceholderArt label={label} className="w-full h-full" />
            </div>
          ))}
        </div>
      </section>

      <section className="max-w-6xl mx-auto px-5 pb-20 text-center">
        <a
          href={buildWhatsAppLink(settings?.whatsapp_number, 'Hello Duchess, I would like to place an order.')}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-block bg-burgundy text-cream px-9 py-4 text-sm font-medium hover:brightness-110 transition"
        >
          Order on WhatsApp
        </a>
      </section>
    </div>
  )
}
