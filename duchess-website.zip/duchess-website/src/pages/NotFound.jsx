import { Link } from 'react-router-dom'

export default function NotFound() {
  return (
    <div className="max-w-xl mx-auto px-5 py-32 text-center">
      <h1 className="font-display text-3xl text-ink mb-4">Page not found</h1>
      <p className="text-charcoal/60 mb-8">That page doesn't exist.</p>
      <Link to="/" className="text-burgundy underline underline-offset-2">Back to home</Link>
    </div>
  )
}
