import { useState } from 'react'
import { useSiteSettings } from '../lib/useSiteSettings'
import { buildWhatsAppLink, buildCustomOrderMessage } from '../lib/whatsapp'
import PlaceholderArt from '../components/PlaceholderArt'

const empty = { name: '', phone: '', type: '', date: '', location: '', details: '' }

export default function CustomOrders() {
  const [form, setForm] = useState(empty)
  const settings = useSiteSettings()

  function update(field, value) {
    setForm((f) => ({ ...f, [field]: value }))
  }

  const ready = form.name && form.phone && form.type
  const waLink = buildWhatsAppLink(settings?.whatsapp_number, buildCustomOrderMessage(form))

  return (
    <div>
      <section className="bg-ink text-cream">
        <div className="max-w-6xl mx-auto px-5 py-16 md:py-20 grid md:grid-cols-2 gap-12 items-center">
          <div>
            <p className="text-gold text-sm tracking-wide mb-4">Celebrations & custom pieces</p>
            <h1 className="font-display text-4xl md:text-5xl leading-tight mb-5">Make it a Duchess moment.</h1>
            <p className="text-cream/70 leading-relaxed max-w-md">
              Custom cakes, celebration platters, and personalised orders — tell us the occasion and we'll take it from there.
            </p>
          </div>
          <div className="aspect-[4/3]">
            <PlaceholderArt label="Custom Order" className="w-full h-full" />
          </div>
        </div>
      </section>

      <section className="max-w-2xl mx-auto px-5 py-16">
        <h2 className="font-display text-2xl text-ink mb-8">Request a custom order</h2>
        <form
          className="space-y-5"
          onSubmit={(e) => {
            e.preventDefault()
            window.open(waLink, '_blank', 'noopener,noreferrer')
          }}
        >
          <Field label="Your name">
            <input required value={form.name} onChange={(e) => update('name', e.target.value)} className="input" />
          </Field>
          <Field label="WhatsApp / phone number">
            <input required value={form.phone} onChange={(e) => update('phone', e.target.value)} className="input" />
          </Field>
          <Field label="Type of order">
            <input required placeholder="e.g. Birthday cake, celebration platter" value={form.type} onChange={(e) => update('type', e.target.value)} className="input" />
          </Field>
          <Field label="Preferred date">
            <input type="date" value={form.date} onChange={(e) => update('date', e.target.value)} className="input" />
          </Field>
          <Field label="Delivery / pickup location">
            <input value={form.location} onChange={(e) => update('location', e.target.value)} className="input" />
          </Field>
          <Field label="Tell us more">
            <textarea rows={4} value={form.details} onChange={(e) => update('details', e.target.value)} className="input" placeholder="Flavour, size, theme, budget — anything that helps." />
          </Field>

          <button
            type="submit"
            disabled={!ready}
            className="w-full bg-burgundy text-cream py-3.5 text-sm font-medium disabled:opacity-40 hover:brightness-110 transition"
          >
            Send request via WhatsApp
          </button>
          <p className="text-xs text-charcoal/50 text-center">
            This opens WhatsApp with your details filled in — you'll review and send it yourself.
          </p>
        </form>
      </section>
    </div>
  )
}

function Field({ label, children }) {
  return (
    <label className="block">
      <span className="block text-sm text-charcoal/70 mb-1.5">{label}</span>
      {children}
    </label>
  )
}
