import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { supabase } from '../lib/supabase'
import { useSiteSettings } from '../lib/useSiteSettings'
import { buildWhatsAppLink } from '../lib/whatsapp'
import PlaceholderArt from '../components/PlaceholderArt'

export default function Home() {
  const [categories, setCategories] = useState([])
  const [featured, setFeatured] = useState([])
  const [branches, setBranches] = useState([])
  const settings = useSiteSettings()

  useEffect(() => {
    supabase.from('categories').select('*').order('sort_order').then(({ data }) => setCategories(data || []))
    supabase
      .from('products')
      .select('*')
      .eq('is_featured', true)
      .eq('is_available', true)
      .limit(4)
      .then(({ data }) => setFeatured(data || []))
    supabase.from('branches').select('*').limit(3).then(({ data }) => setBranches(data || []))
  }, [])

  const waLink = buildWhatsAppLink(settings?.whatsapp_number, 'Hello Duchess, I would like to place an order.')

  return (
    <div>
      {/* Hero */}
      <section className="bg-ink text-cream">
        <div className="max-w-6xl mx-auto px-5 py-20 md:py-28 grid md:grid-cols-2 gap-12 items-center">
          <div>
            <p className="text-gold text-sm tracking-wide mb-4">Shawarma · Pizza · Cakes · Pastries</p>
            <h1 className="font-display text-4xl md:text-6xl leading-[1.05] mb-6">
              A little indulgence, freshly made.
            </h1>
            <p className="text-cream/70 text-base md:text-lg leading-relaxed max-w-md mb-8">
              From loaded shawarma to celebration cakes — Duchess brings it fresh, and straight to your WhatsApp order.
            </p>
            <div className="flex flex-wrap gap-4">
              <a href={waLink} target="_blank" rel="noopener noreferrer" className="bg-burgundy px-7 py-3.5 text-sm font-medium hover:brightness-110 transition">
                Order on WhatsApp
              </a>
              <Link to="/menu" className="border border-gold/50 px-7 py-3.5 text-sm font-medium hover:border-gold transition">
                View Menu
              </Link>
            </div>
          </div>
          <div className="aspect-[4/3]">
            <PlaceholderArt label="Duchess Hero" className="w-full h-full" />
          </div>
        </div>
      </section>

      {/* Categories */}
      {categories.length > 0 && (
        <section className="max-w-6xl mx-auto px-5 py-16">
          <h2 className="font-display text-2xl md:text-3xl text-ink mb-8">What we're known for</h2>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            {categories.map((c) => (
              <Link
                key={c.id}
                to="/menu"
                className="aspect-square relative flex items-end p-4 group overflow-hidden"
              >
                <PlaceholderArt label={c.name} className="absolute inset-0 group-hover:scale-105 transition-transform duration-500" />
                <span className="relative text-cream font-display text-lg">{c.name}</span>
              </Link>
            ))}
          </div>
        </section>
      )}

      {/* Featured products */}
      {featured.length > 0 && (
        <section className="bg-blush/40 py-16">
          <div className="max-w-6xl mx-auto px-5">
            <h2 className="font-display text-2xl md:text-3xl text-ink mb-8">Fan favourites</h2>
            <div className="grid sm:grid-cols-2 md:grid-cols-4 gap-5">
              {featured.map((p) => (
                <div key={p.id} className="bg-white/60">
                  <div className="aspect-square">
                    <PlaceholderArt label={p.name} className="w-full h-full" />
                  </div>
                  <div className="p-3">
                    <p className="font-display text-base text-ink">{p.name}</p>
                    <p className="text-xs text-burgundy mt-1">
                      {p.price ? `₦${Number(p.price).toLocaleString()}` : 'Price on request'}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Custom order teaser */}
      <section className="max-w-6xl mx-auto px-5 py-20 grid md:grid-cols-2 gap-12 items-center">
        <div className="aspect-[4/3] order-2 md:order-1">
          <PlaceholderArt label="Custom Cake" className="w-full h-full" />
        </div>
        <div className="order-1 md:order-2">
          <p className="text-burgundy text-sm tracking-wide mb-3">Celebrations</p>
          <h2 className="font-display text-3xl md:text-4xl text-ink mb-5">Make it a Duchess moment.</h2>
          <p className="text-charcoal/70 leading-relaxed mb-7 max-w-md">
            Birthdays, proposals, small get-togethers — tell us what you're celebrating and we'll put it together.
          </p>
          <Link to="/custom-orders" className="inline-block bg-ink text-cream px-7 py-3.5 text-sm font-medium hover:bg-charcoal transition">
            Start a custom order
          </Link>
        </div>
      </section>

      {/* Branches preview */}
      {branches.length > 0 && (
        <section className="bg-ink text-cream py-16">
          <div className="max-w-6xl mx-auto px-5">
            <div className="flex items-baseline justify-between mb-8">
              <h2 className="font-display text-2xl md:text-3xl">Find us</h2>
              <Link to="/locations" className="text-gold text-sm hover:underline">All locations</Link>
            </div>
            <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-6">
              {branches.map((b) => (
                <div key={b.id} className="border border-cream/15 p-5">
                  <p className="font-display text-lg mb-1">{b.name}</p>
                  <p className="text-cream/60 text-sm">{b.address || '[Address to be confirmed]'}</p>
                </div>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* Final CTA */}
      <section className="max-w-6xl mx-auto px-5 py-20 text-center">
        <h2 className="font-display text-3xl md:text-4xl text-ink mb-5">Hungry already?</h2>
        <a href={waLink} target="_blank" rel="noopener noreferrer" className="inline-block bg-burgundy text-cream px-9 py-4 text-sm font-medium hover:brightness-110 transition">
          Order on WhatsApp
        </a>
      </section>
    </div>
  )
}
