import { NavLink, Navigate, Outlet } from 'react-router-dom'
import { useAuth } from '../lib/useAuth'
import { supabase } from '../lib/supabase'
import Monogram from '../components/Monogram'

const links = [
  { to: '/admin/products', label: 'Products' },
  { to: '/admin/branches', label: 'Branches' },
  { to: '/admin/promotions', label: 'Promotions' },
  { to: '/admin/settings', label: 'Settings' },
]

export default function AdminLayout() {
  const { isLoggedIn, loading } = useAuth()

  if (loading) {
    return <div className="min-h-screen bg-cream flex items-center justify-center text-charcoal/50">Loading…</div>
  }

  if (!isLoggedIn) {
    return <Navigate to="/admin/login" replace />
  }

  return (
    <div className="min-h-screen bg-cream flex flex-col md:flex-row">
      <aside className="md:w-56 bg-ink text-cream md:min-h-screen flex md:flex-col">
        <div className="hidden md:flex items-center gap-2 px-5 py-6">
          <Monogram className="w-7 h-7" light />
          <span className="font-display">Duchess</span>
        </div>
        <nav className="flex md:flex-col overflow-x-auto md:overflow-visible px-3 md:px-3 py-2 md:py-2 gap-1 flex-1">
          {links.map((l) => (
            <NavLink
              key={l.to}
              to={l.to}
              className={({ isActive }) =>
                `shrink-0 px-3 py-2.5 text-sm rounded ${isActive ? 'bg-burgundy text-cream' : 'text-cream/70 hover:text-cream'}`
              }
            >
              {l.label}
            </NavLink>
          ))}
        </nav>
        <button
          onClick={() => supabase.auth.signOut()}
          className="text-sm text-cream/60 hover:text-cream px-5 py-4 text-left"
        >
          Sign out
        </button>
      </aside>
      <main className="flex-1 p-5 md:p-8 max-w-4xl">
        <Outlet />
      </main>
    </div>
  )
}
