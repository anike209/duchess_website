import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { supabase } from '../lib/supabase'
import Monogram from '../components/Monogram'

export default function AdminLogin() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)
  const navigate = useNavigate()

  async function handleSubmit(e) {
    e.preventDefault()
    setLoading(true)
    setError('')
    const { error } = await supabase.auth.signInWithPassword({ email, password })
    setLoading(false)
    if (error) {
      setError('Email or password is incorrect.')
      return
    }
    navigate('/admin/products')
  }

  return (
    <div className="min-h-screen bg-ink flex items-center justify-center px-5">
      <div className="w-full max-w-sm">
        <div className="flex flex-col items-center mb-8">
          <Monogram className="w-12 h-12 mb-3" light />
          <h1 className="font-display text-2xl text-cream">Duchess Admin</h1>
        </div>
        <form onSubmit={handleSubmit} className="space-y-4 bg-cream p-6">
          <label className="block">
            <span className="block text-sm text-charcoal/70 mb-1.5">Email</span>
            <input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} className="input" />
          </label>
          <label className="block">
            <span className="block text-sm text-charcoal/70 mb-1.5">Password</span>
            <input type="password" required value={password} onChange={(e) => setPassword(e.target.value)} className="input" />
          </label>
          {error && <p className="text-sm text-burgundy">{error}</p>}
          <button disabled={loading} className="w-full bg-burgundy text-cream py-3 text-sm font-medium disabled:opacity-50">
            {loading ? 'Signing in…' : 'Sign in'}
          </button>
        </form>
      </div>
    </div>
  )
}
