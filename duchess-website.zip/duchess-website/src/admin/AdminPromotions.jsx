import { useEffect, useState } from 'react'
import { supabase } from '../lib/supabase'

const emptyForm = { id: null, title: '', image_url: '', is_active: true }

export default function AdminPromotions() {
  const [promos, setPromos] = useState([])
  const [form, setForm] = useState(emptyForm)
  const [uploading, setUploading] = useState(false)
  const [saving, setSaving] = useState(false)

  async function load() {
    const { data } = await supabase.from('promotions').select('*').order('id', { ascending: false })
    setPromos(data || [])
  }
  useEffect(() => { load() }, [])

  async function handleImageUpload(e) {
    const file = e.target.files[0]
    if (!file) return
    setUploading(true)
    const path = `promotions/${Date.now()}-${file.name}`
    const { error } = await supabase.storage.from('duchess-images').upload(path, file)
    if (error) {
      alert('Upload failed: ' + error.message)
      setUploading(false)
      return
    }
    const { data } = supabase.storage.from('duchess-images').getPublicUrl(path)
    setForm((f) => ({ ...f, image_url: data.publicUrl }))
    setUploading(false)
  }

  async function handleSubmit(e) {
    e.preventDefault()
    setSaving(true)
    const payload = { title: form.title, image_url: form.image_url || null, is_active: form.is_active }
    if (form.id) await supabase.from('promotions').update(payload).eq('id', form.id)
    else await supabase.from('promotions').insert(payload)
    setSaving(false)
    setForm(emptyForm)
    load()
  }

  async function remove(id) {
    if (!confirm('Delete this promotion?')) return
    await supabase.from('promotions').delete().eq('id', id)
    load()
  }

  return (
    <div>
      <h1 className="font-display text-2xl text-ink mb-6">Promotions</h1>
      <p className="text-sm text-charcoal/60 mb-6">These show on the About page (and homepage once you have a few). Turn one off any time without deleting it.</p>

      <form onSubmit={handleSubmit} className="bg-white/50 border border-gold/25 p-5 mb-10 space-y-4">
        <p className="text-sm font-medium text-ink">{form.id ? 'Edit promotion' : 'Add new promotion'}</p>
        <label className="block">
          <span className="block text-xs text-charcoal/60 mb-1">Title</span>
          <input required value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} className="input" />
        </label>
        <label className="block">
          <span className="block text-xs text-charcoal/60 mb-1">Image</span>
          <input type="file" accept="image/*" onChange={handleImageUpload} className="text-sm" />
        </label>
        {form.image_url && <img src={form.image_url} alt="Preview" className="w-28 h-28 object-cover" />}
        <label className="flex items-center gap-2 text-sm">
          <input type="checkbox" checked={form.is_active} onChange={(e) => setForm({ ...form, is_active: e.target.checked })} />
          Active (shown on site)
        </label>
        <div className="flex gap-3">
          <button disabled={saving || uploading} className="bg-burgundy text-cream px-5 py-2.5 text-sm disabled:opacity-50">
            {uploading ? 'Uploading…' : saving ? 'Saving…' : form.id ? 'Save changes' : 'Add promotion'}
          </button>
          {form.id && <button type="button" onClick={() => setForm(emptyForm)} className="text-sm text-charcoal/60">Cancel</button>}
        </div>
      </form>

      <div className="space-y-3">
        {promos.map((p) => (
          <div key={p.id} className="flex items-center gap-4 border border-charcoal/10 p-3">
            {p.image_url ? <img src={p.image_url} alt={p.title} className="w-14 h-14 object-cover shrink-0" /> : <div className="w-14 h-14 bg-blush shrink-0" />}
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-ink truncate">{p.title}</p>
              <p className="text-xs text-charcoal/50">{p.is_active ? 'Active' : 'Hidden'}</p>
            </div>
            <button onClick={() => setForm({ ...emptyForm, ...p })} className="text-xs text-burgundy shrink-0">Edit</button>
            <button onClick={() => remove(p.id)} className="text-xs text-charcoal/40 shrink-0">Delete</button>
          </div>
        ))}
        {promos.length === 0 && <p className="text-sm text-charcoal/50">No promotions yet.</p>}
      </div>
    </div>
  )
}
