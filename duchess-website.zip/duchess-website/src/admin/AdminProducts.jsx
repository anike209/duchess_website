import { useEffect, useState } from 'react'
import { supabase } from '../lib/supabase'

const emptyForm = { id: null, name: '', description: '', price: '', category_id: '', is_available: true, is_featured: false, image_url: '' }

export default function AdminProducts() {
  const [products, setProducts] = useState([])
  const [categories, setCategories] = useState([])
  const [form, setForm] = useState(emptyForm)
  const [uploading, setUploading] = useState(false)
  const [saving, setSaving] = useState(false)

  async function load() {
    const { data: p } = await supabase.from('products').select('*').order('created_at', { ascending: false })
    const { data: c } = await supabase.from('categories').select('*').order('sort_order')
    setProducts(p || [])
    setCategories(c || [])
  }

  useEffect(() => { load() }, [])

  function edit(product) {
    setForm({ ...emptyForm, ...product, price: product.price ?? '' })
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  function resetForm() {
    setForm(emptyForm)
  }

  async function handleImageUpload(e) {
    const file = e.target.files[0]
    if (!file) return
    setUploading(true)
    const path = `products/${Date.now()}-${file.name}`
    const { error } = await supabase.storage.from('duchess-images').upload(path, file)
    if (error) {
      alert('Image upload failed: ' + error.message)
      setUploading(false)
      return
    }
    const { data } = supabase.storage.from('duchess-images').getPublicUrl(path)
    setForm((f) => ({ ...f, image_url: data.publicUrl }))
    setUploading(false)
  }

  async function handleSubmit(e) {
    e.preventDefault()
    setSaving(true)
    const payload = {
      name: form.name,
      description: form.description || null,
      price: form.price === '' ? null : Number(form.price),
      category_id: form.category_id || null,
      is_available: form.is_available,
      is_featured: form.is_featured,
      image_url: form.image_url || null,
    }
    if (form.id) {
      await supabase.from('products').update(payload).eq('id', form.id)
    } else {
      await supabase.from('products').insert(payload)
    }
    setSaving(false)
    resetForm()
    load()
  }

  async function remove(id) {
    if (!confirm('Delete this product? This cannot be undone.')) return
    await supabase.from('products').delete().eq('id', id)
    load()
  }

  async function toggleAvailable(product) {
    await supabase.from('products').update({ is_available: !product.is_available }).eq('id', product.id)
    load()
  }

  return (
    <div>
      <h1 className="font-display text-2xl text-ink mb-6">Products</h1>

      <form onSubmit={handleSubmit} className="bg-white/50 border border-gold/25 p-5 mb-10 space-y-4">
        <p className="text-sm font-medium text-ink">{form.id ? 'Edit product' : 'Add new product'}</p>
        <div className="grid sm:grid-cols-2 gap-4">
          <label className="block">
            <span className="block text-xs text-charcoal/60 mb-1">Name</span>
            <input required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="input" />
          </label>
          <label className="block">
            <span className="block text-xs text-charcoal/60 mb-1">Price (₦, leave blank for "Price on request")</span>
            <input type="number" min="0" value={form.price} onChange={(e) => setForm({ ...form, price: e.target.value })} className="input" />
          </label>
        </div>
        <label className="block">
          <span className="block text-xs text-charcoal/60 mb-1">Description</span>
          <textarea rows={2} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} className="input" />
        </label>
        <div className="grid sm:grid-cols-2 gap-4 items-end">
          <label className="block">
            <span className="block text-xs text-charcoal/60 mb-1">Category</span>
            <select value={form.category_id} onChange={(e) => setForm({ ...form, category_id: e.target.value })} className="input">
              <option value="">No category</option>
              {categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
            </select>
          </label>
          <label className="block">
            <span className="block text-xs text-charcoal/60 mb-1">Photo</span>
            <input type="file" accept="image/*" onChange={handleImageUpload} className="text-sm" />
          </label>
        </div>
        {form.image_url && <img src={form.image_url} alt="Preview" className="w-28 h-28 object-cover" />}
        <div className="flex gap-6">
          <label className="flex items-center gap-2 text-sm">
            <input type="checkbox" checked={form.is_available} onChange={(e) => setForm({ ...form, is_available: e.target.checked })} />
            Available
          </label>
          <label className="flex items-center gap-2 text-sm">
            <input type="checkbox" checked={form.is_featured} onChange={(e) => setForm({ ...form, is_featured: e.target.checked })} />
            Featured on homepage
          </label>
        </div>
        <div className="flex gap-3">
          <button disabled={saving || uploading} className="bg-burgundy text-cream px-5 py-2.5 text-sm disabled:opacity-50">
            {uploading ? 'Uploading image…' : saving ? 'Saving…' : form.id ? 'Save changes' : 'Add product'}
          </button>
          {form.id && (
            <button type="button" onClick={resetForm} className="text-sm text-charcoal/60">Cancel</button>
          )}
        </div>
      </form>

      <div className="space-y-3">
        {products.map((p) => (
          <div key={p.id} className="flex items-center gap-4 border border-charcoal/10 p-3">
            {p.image_url ? (
              <img src={p.image_url} alt={p.name} className="w-14 h-14 object-cover shrink-0" />
            ) : (
              <div className="w-14 h-14 bg-blush shrink-0" />
            )}
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-ink truncate">{p.name}</p>
              <p className="text-xs text-charcoal/50">
                {p.price ? `₦${Number(p.price).toLocaleString()}` : 'Price on request'}
                {!p.is_available && ' · Unavailable'}
              </p>
            </div>
            <button onClick={() => toggleAvailable(p)} className="text-xs text-charcoal/60 border border-charcoal/20 px-2.5 py-1.5 shrink-0">
              {p.is_available ? 'Mark unavailable' : 'Mark available'}
            </button>
            <button onClick={() => edit(p)} className="text-xs text-burgundy shrink-0">Edit</button>
            <button onClick={() => remove(p.id)} className="text-xs text-charcoal/40 shrink-0">Delete</button>
          </div>
        ))}
        {products.length === 0 && <p className="text-sm text-charcoal/50">No products yet.</p>}
      </div>
    </div>
  )
}
