import { useEffect, useState } from 'react'
import { supabase } from '../lib/supabase'

export default function AdminSettings() {
  const [form, setForm] = useState({ whatsapp_number: '', custom_order_info: '' })
  const [saving, setSaving] = useState(false)
  const [saved, setSaved] = useState(false)

  useEffect(() => {
    supabase.from('site_settings').select('*').eq('id', 1).maybeSingle().then(({ data }) => {
      if (data) setForm({ whatsapp_number: data.whatsapp_number || '', custom_order_info: data.custom_order_info || '' })
    })
  }, [])

  async function handleSubmit(e) {
    e.preventDefault()
    setSaving(true)
    await supabase.from('site_settings').upsert({ id: 1, ...form })
    setSaving(false)
    setSaved(true)
    setTimeout(() => setSaved(false), 2000)
  }

  return (
    <div>
      <h1 className="font-display text-2xl text-ink mb-6">Settings</h1>
      <form onSubmit={handleSubmit} className="bg-white/50 border border-gold/25 p-5 space-y-5 max-w-lg">
        <label className="block">
          <span className="block text-xs text-charcoal/60 mb-1">WhatsApp order number</span>
          <input
            placeholder="234XXXXXXXXXX (country code, no + or spaces)"
            value={form.whatsapp_number}
            onChange={(e) => setForm({ ...form, whatsapp_number: e.target.value })}
            className="input"
          />
          <span className="block text-xs text-charcoal/40 mt-1">This one number powers every "Order on WhatsApp" button site-wide.</span>
        </label>
        <label className="block">
          <span className="block text-xs text-charcoal/60 mb-1">Custom order info (shown on Custom Orders page)</span>
          <textarea rows={4} value={form.custom_order_info} onChange={(e) => setForm({ ...form, custom_order_info: e.target.value })} className="input" />
        </label>
        <button disabled={saving} className="bg-burgundy text-cream px-5 py-2.5 text-sm disabled:opacity-50">
          {saving ? 'Saving…' : 'Save settings'}
        </button>
        {saved && <span className="text-sm text-charcoal/60 ml-3">Saved.</span>}
      </form>
    </div>
  )
}
