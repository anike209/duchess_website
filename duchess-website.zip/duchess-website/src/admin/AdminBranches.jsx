import { useEffect, useState } from 'react'
import { supabase } from '../lib/supabase'

const emptyForm = { id: null, name: '', address: '', hours: '', phone: '', maps_link: '' }

export default function AdminBranches() {
  const [branches, setBranches] = useState([])
  const [form, setForm] = useState(emptyForm)
  const [saving, setSaving] = useState(false)

  async function load() {
    const { data } = await supabase.from('branches').select('*').order('name')
    setBranches(data || [])
  }
  useEffect(() => { load() }, [])

  async function handleSubmit(e) {
    e.preventDefault()
    setSaving(true)
    const payload = { name: form.name, address: form.address || null, hours: form.hours || null, phone: form.phone || null, maps_link: form.maps_link || null }
    if (form.id) await supabase.from('branches').update(payload).eq('id', form.id)
    else await supabase.from('branches').insert(payload)
    setSaving(false)
    setForm(emptyForm)
    load()
  }

  async function remove(id) {
    if (!confirm('Delete this branch?')) return
    await supabase.from('branches').delete().eq('id', id)
    load()
  }

  return (
    <div>
      <h1 className="font-display text-2xl text-ink mb-6">Branches</h1>

      <form onSubmit={handleSubmit} className="bg-white/50 border border-gold/25 p-5 mb-10 space-y-4">
        <p className="text-sm font-medium text-ink">{form.id ? 'Edit branch' : 'Add new branch'}</p>
        <label className="block">
          <span className="block text-xs text-charcoal/60 mb-1">Branch name</span>
          <input required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="input" />
        </label>
        <label className="block">
          <span className="block text-xs text-charcoal/60 mb-1">Address</span>
          <input value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} className="input" />
        </label>
        <div className="grid sm:grid-cols-2 gap-4">
          <label className="block">
            <span className="block text-xs text-charcoal/60 mb-1">Opening hours</span>
            <input placeholder="e.g. Mon–Sat, 9am–9pm" value={form.hours} onChange={(e) => setForm({ ...form, hours: e.target.value })} className="input" />
          </label>
          <label className="block">
            <span className="block text-xs text-charcoal/60 mb-1">Phone (optional)</span>
            <input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} className="input" />
          </label>
        </div>
        <label className="block">
          <span className="block text-xs text-charcoal/60 mb-1">Google Maps link (optional)</span>
          <input value={form.maps_link} onChange={(e) => setForm({ ...form, maps_link: e.target.value })} className="input" />
        </label>
        <div className="flex gap-3">
          <button disabled={saving} className="bg-burgundy text-cream px-5 py-2.5 text-sm disabled:opacity-50">
            {saving ? 'Saving…' : form.id ? 'Save changes' : 'Add branch'}
          </button>
          {form.id && <button type="button" onClick={() => setForm(emptyForm)} className="text-sm text-charcoal/60">Cancel</button>}
        </div>
      </form>

      <div className="space-y-3">
        {branches.map((b) => (
          <div key={b.id} className="flex items-center gap-4 border border-charcoal/10 p-3">
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-ink">{b.name}</p>
              <p className="text-xs text-charcoal/50 truncate">{b.address || 'No address yet'}</p>
            </div>
            <button onClick={() => setForm({ ...emptyForm, ...b })} className="text-xs text-burgundy shrink-0">Edit</button>
            <button onClick={() => remove(b.id)} className="text-xs text-charcoal/40 shrink-0">Delete</button>
          </div>
        ))}
        {branches.length === 0 && <p className="text-sm text-charcoal/50">No branches yet.</p>}
      </div>
    </div>
  )
}
